package com.solusindo.kreativa.companyprofilekreativaadmin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.solusindo.kreativa.companyprofilekreativaadmin.background.Bg_login;
import com.solusindo.kreativa.companyprofilekreativaadmin.background.Bg_profil;
import com.solusindo.kreativa.companyprofilekreativaadmin.interfaces.AsyncResponse;

public class EditProfilActivity extends AppCompatActivity implements AsyncResponse {
    EditText nama_perusahaan, alamat, no_telp, email,instagram, desk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profil);
        nama_perusahaan = (EditText)findViewById(R.id.ET_pp_namap);
        alamat = (EditText)findViewById(R.id.ET_pp_alamatp);
        no_telp = (EditText)findViewById(R.id.ET_pp_notelp);
        email = (EditText)findViewById(R.id.ET_pp_email);
        instagram = (EditText)findViewById(R.id.ET_pp_instagram);
        desk = (EditText)findViewById(R.id.ET_pp_deskripsi);

        String str_nama_p = getIntent().getStringExtra("NAMA_PERUSAHAAN"),
                str_desk = getIntent().getStringExtra("DESK_PERUSAHAAN"),
                str_email = getIntent().getStringExtra("EMAIL"),
                str_telp = getIntent().getStringExtra("TELP"),
                str_alamat = getIntent().getStringExtra("ALAMAT"),
                str_instagram = getIntent().getStringExtra("INSTAGRAM");

        nama_perusahaan.setText(str_nama_p);
        alamat.setText(str_alamat);
        no_telp.setText(str_telp);
        email.setText(str_email);
        instagram.setText(str_instagram);
        desk.setText(str_desk);


    }

    public void onEdit(View view) {
        String str_nama_p = getIntent().getStringExtra("NAMA_PERUSAHAAN"),
                str_desk = getIntent().getStringExtra("DESK_PERUSAHAAN"),
                str_email = getIntent().getStringExtra("EMAIL"),
                str_telp = getIntent().getStringExtra("TELP"),
                str_alamat = getIntent().getStringExtra("ALAMAT"),
                str_instagram = getIntent().getStringExtra("INSTAGRAM");
        String type = "update";
        Bg_profil bg = new Bg_profil(this);
        bg.delegate = this;
        bg.execute(type,nama_perusahaan.getText().toString(),alamat.getText().toString(),no_telp.getText().toString(),
                email.getText().toString(), instagram.getText().toString(), desk.getText().toString());
    }


    public void onBatal(View view) {
        finish();
    }

    @Override
    public void processfinish(String output) {
        if(output.equals("Update Data Berhasil")){
            Toast.makeText(getApplicationContext(), "Data Berhasil di Update", Toast.LENGTH_LONG).show();
            ProfilActivity profilActivity = new ProfilActivity();
            profilActivity.PA.refresh();
            finish();
        } else {
            Toast.makeText(getBaseContext(), output, Toast.LENGTH_LONG).show();
        }
    }
}
