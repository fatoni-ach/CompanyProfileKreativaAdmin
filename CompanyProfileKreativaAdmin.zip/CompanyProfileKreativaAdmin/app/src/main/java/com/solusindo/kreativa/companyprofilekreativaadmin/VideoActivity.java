package com.solusindo.kreativa.companyprofilekreativaadmin;

import android.content.Intent;
import android.net.Uri;
import android.support.design.widget.TextInputEditText;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.MediaController;
import android.widget.Toast;
import android.widget.VideoView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.youtube.player.YouTubeBaseActivity;
import com.google.android.youtube.player.YouTubeInitializationResult;
import com.google.android.youtube.player.YouTubePlayer;
import com.google.android.youtube.player.YouTubePlayerView;
import com.solusindo.kreativa.companyprofilekreativaadmin.background.Bg_profil;
import com.solusindo.kreativa.companyprofilekreativaadmin.background.Bg_url;
import com.solusindo.kreativa.companyprofilekreativaadmin.interfaces.AsyncResponse;
import com.solusindo.kreativa.companyprofilekreativaadmin.table.Profil;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.List;

public class VideoActivity extends YouTubeBaseActivity implements YouTubePlayer.OnInitializedListener , AsyncResponse {

    String videoUrl = "https://www.youtube.com/watch?v=4_rSNJEBEIw&t=918s";
    public static final String API_KEY = "AIzaSyDnzZHwUEcMg9ET0W2B47eO4-iMNNClT94";
//    public String VIDEO_ID = "https://www.youtube.com/watch?v=GdTLMQKuOVI";
    public String VIDEO_ID = "";
    String[] str_split;
    String video_url;
    private JsonArrayRequest arrayRequest;
    private RequestQueue requestQueue;
//    private List<Profil> lstData;
    YouTubePlayerView youTubePlayerView;
    LinkDatabase linkDatabase;
    TextInputEditText video;
    VideoView playVideo;
    MediaController mediaC;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);
        video = (TextInputEditText)findViewById(R.id.ET_video_link);
        str_split = new String[10];
        video_url = new String();
        linkDatabase = new LinkDatabase();
        youTubePlayerView = (YouTubePlayerView) findViewById(R.id.YV_video);
        geturl();
        youTubePlayerView.initialize(API_KEY, this);

    }

    private void geturl() {
        String url      =   linkDatabase.linkurl()+"url.php?operasi=view_video";
        arrayRequest = new JsonArrayRequest(url, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                try {
                    JSONObject jsonObject = response.getJSONObject(0);
//                    id = String.valueOf(jsonObject.getInt("ID_PROFIL"));
//                    str_nama_perusahaan = jsonObject.getString("NAMA_PERUSAHAAN");
                    video_url = jsonObject.getString("URL_VIDEO_PROFIL");
                    Toast.makeText(getBaseContext(), video_url.toString(), Toast.LENGTH_LONG).show();
                    video.setText("https://www.youtube.com/watch?v="+video_url);
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(getBaseContext(), e.toString(), Toast.LENGTH_LONG).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.d("error", error.toString());
            }
        }
        );
        requestQueue    =   Volley.newRequestQueue(this);
        requestQueue.add(arrayRequest);
    }

    public void onSimpan(View view) {
        try {
            String str_link = video.getText().toString();
            if(str_link.length()>12){
                str_split = str_link.split("/");
                String split = str_split[3];
                VIDEO_ID = split.substring(8, 19);
            }else{ VIDEO_ID = str_link;}
            String type = "update_video";
            Bg_url bg = new Bg_url(this);
            bg.delegate= this;
            bg.execute(type, VIDEO_ID);
            youTubePlayerView.initialize(API_KEY, this);
        }catch (Exception e){
            e.printStackTrace();
            Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
        }
//        startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(link)));
//        Log.i("Video", "Video Playing....");


    }

    public void onDelete(View view) {
        video.setText("");
    }

    public void onBack(View view) {
        finish();
    }

    @Override
    public void onInitializationSuccess(YouTubePlayer.Provider provider, YouTubePlayer player, boolean b) {
        player.setPlayerStateChangeListener(playerStateChangeListener);
        player.setPlaybackEventListener(playbackEventListener);


        /** Start buffering **/
        if (!b) {
            player.cueVideo(VIDEO_ID);
        }
    }

    @Override
    public void onInitializationFailure(YouTubePlayer.Provider provider, YouTubeInitializationResult youTubeInitializationResult) {
        Toast.makeText(this, "Failured to Initialize!", Toast.LENGTH_LONG).show();
    }

    private YouTubePlayer.PlaybackEventListener playbackEventListener = new YouTubePlayer.PlaybackEventListener() {
        @Override
        public void onBuffering(boolean arg0) {
        }
        @Override
        public void onPaused() {
        }
        @Override
        public void onPlaying() {
        }
        @Override
        public void onSeekTo(int arg0) {
        }
        @Override
        public void onStopped() {
        }
    };

    private YouTubePlayer.PlayerStateChangeListener playerStateChangeListener = new YouTubePlayer.PlayerStateChangeListener() {
        @Override
        public void onAdStarted() {
        }
        @Override
        public void onError(YouTubePlayer.ErrorReason arg0) {
        }
        @Override
        public void onLoaded(String arg0) {
        }
        @Override
        public void onLoading() {
        }
        @Override
        public void onVideoEnded() {
        }
        @Override
        public void onVideoStarted() {
        }
    };

    @Override
    public void processfinish(String output) {
        if(output.equals("Update Video Berhasil")){
            Toast.makeText(getApplicationContext(), "Link Berhasil Di Simpan", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(getBaseContext(), output, Toast.LENGTH_LONG).show();
        }
    }

    public void onYoutube(View view) {
        startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/watch?v="+VIDEO_ID)));
        Log.i("Video", "Video Playing....");
    }
}
