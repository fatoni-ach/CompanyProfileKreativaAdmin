package com.solusindo.kreativa.companyprofilekreativaadmin.interfaces;

public interface AsyncResponse  {
    void processfinish(String output);
}
