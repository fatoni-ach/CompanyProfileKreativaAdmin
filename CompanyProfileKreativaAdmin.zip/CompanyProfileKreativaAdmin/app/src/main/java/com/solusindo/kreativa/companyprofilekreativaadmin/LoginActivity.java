package com.solusindo.kreativa.companyprofilekreativaadmin;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.solusindo.kreativa.companyprofilekreativaadmin.background.Bg_login;
import com.solusindo.kreativa.companyprofilekreativaadmin.interfaces.AsyncResponse;

public class LoginActivity extends AppCompatActivity implements AsyncResponse {
    EditText et_username, et_password;
    LinkDatabase linkDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        et_username = (EditText)findViewById(R.id.ET_login_username);
        et_password = (EditText)findViewById(R.id.ET_login_password);

    }

    public void onLogin(View v){
//        String user = et_username.getText().toString();
//        String pass = et_password.getText().toString();
//        if(user.equals("")||pass.equals("")){
//            Toast.makeText(getBaseContext(), "Masukkan username dan password terlebih dahulu",Toast.LENGTH_LONG).show();
//        }else{
//        String type = "login";
//        Bg_login bg = new Bg_login(this);
//        bg.delegate = this;
//        bg.execute(type,user,pass);}
        Intent intent = new Intent(this, HomeActivity.class);
        startActivity(intent);
    }

    @Override
    public void processfinish(String output) {
        if(output.equals("login sukses")){
            Intent intent = new Intent(this, HomeActivity.class);
            startActivity(intent);
        } else Toast.makeText(getBaseContext(), output, Toast.LENGTH_LONG).show();



    }
}
