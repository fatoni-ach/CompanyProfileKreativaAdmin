package com.solusindo.kreativa.companyprofilekreativaadmin;

import android.content.Context;

public class LinkDatabase {
    Context context;
    public LinkDatabase(){
    }
    public String linkurl(){
        return "http://192.168.137.1/server/";
    }
}
